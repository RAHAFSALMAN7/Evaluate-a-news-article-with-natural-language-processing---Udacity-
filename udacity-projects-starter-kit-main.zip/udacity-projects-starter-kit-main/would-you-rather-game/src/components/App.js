import React, { Component } from 'react'

class App extends Component {
  render() {
    return (
      <div>
        Starter Code
      </div>
    )
  }
}

export default App