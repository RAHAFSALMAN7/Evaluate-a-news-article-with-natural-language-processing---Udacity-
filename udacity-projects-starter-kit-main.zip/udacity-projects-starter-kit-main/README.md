![Udacity Banner](https://d20vrrgs8k4bvw.cloudfront.net/images/open-graph/udacity.png)

<h2 align="center">Udacity Starter Kit For Frontend Projects</h2>
<h3 align="center">This starter files doesn't Belong by anyway to udacity is self, it's only my way to improve the
experience of the projects and make things easier for the students by following step-by-step approach</h3>

<p align="center">
 <a href="https://www.linkedin.com/in/mohammedelzanaty129/">
    <img alt="Follow Me on LinkedIn" src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white"></a>
<a href="https://twitter.com/mohammdelzanaty">
    <img alt="Follow Me on Twitter" src="https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white"></a>
</p>

## Solve the project in three steps 

1. Select the project you need to start with 
    - [Evaluate a News Article with Natural Language Processing](./evaluate-news-article/README.md)
2. Solve All Todos in the code 
3. Submit your project 

------

Made with ❤️️ and javascript